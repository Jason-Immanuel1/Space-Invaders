 

public enum GameStateManager {
    MAIN_MENU, PLAYING, PAUSED, GAME_OVER
}
