import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.MenuBar;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import java.io.InputStream;

public class StartMenu {
    private static final int WIDTH = 800;
    private static final int HEIGHT = 800;

    public static Scene createStartMenu(Stage stage) {
        BorderPane borderPane = new BorderPane();
        
        //same backround as main game
        InputStream inputStream = StartMenu.class.getResourceAsStream("/sprites/spaceinvadersbackground.png");
        assert inputStream != null;
        Image bgImage = new Image(inputStream);
        ImageView bgView = new ImageView(bgImage);
        bgView.setFitWidth(WIDTH);
        bgView.setFitHeight(HEIGHT);
        
        StackPane centerContent = new StackPane();
        
        centerContent.getChildren().add(bgView);
        
        Button startButton = new Button("Start Game");
        startButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-font-size: 20px; -fx-padding: 10 20 10 20;");
        startButton.setOnAction(e -> {
            SpaceInvadersApplication.startGame(stage);
        });
        
        centerContent.getChildren().add(startButton); //button on top of backdro
        
        MenuBar menuBar = GameMenu.createMenuBar();
        
        borderPane.setTop(menuBar);
        borderPane.setCenter(centerContent);
        
        return new Scene(borderPane, WIDTH, HEIGHT);
    }
}